/* PublishHiScore created on 25.09.2006 */
package net.sourceforge.jetris.io;

public class PublishHiScore {

    public static void publish(HiScore hs) throws Exception {
        
    }
}
