/* ResClass created on 28.09.2006 */
package res;

public final class ResClass {

}
