This is our final project submission!

------------------------------------------------------------------------------------------------
-Running the Code
------------------------------------------------------------------------------------------------
luckyJetris.exe is a wrapped jar that checks for your version of java and has all needed classes and resources. In an emergency where this file doesn't work on your system, Code\luckyJetris.jar should work. If this still doesn't run, try double clicking Code/comp_all.bat and then Code/JETRIS.bat. If this doesnt work, please update your version of java and try again.

------------------------------------------------------------------------------------------------
-Locating the Code
------------------------------------------------------------------------------------------------
All our java source files are in the Code directory.

------------------------------------------------------------------------------------------------
-Locating the Documentation
------------------------------------------------------------------------------------------------
All our documentation is in the doc directory. This file can also be accessed from the game's main menu.

Thank you, enjoy

- Lucky Number Sevens - CEN3031 - Fall 2007
  http://plaza.ufl.edu/rgadala/luckynumber7s/index.html